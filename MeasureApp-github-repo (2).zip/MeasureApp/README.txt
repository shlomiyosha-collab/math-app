פותחים את התיקייה ב-Android Studio (File > Open), ממתינים לסנכרון, ואז Build > Build APK(s).
הקובץ המוכן יופיע ב-app/build/outputs/apk/debug/app-debug.apk. מעבירים אותו לטלפון ומתקינים.
